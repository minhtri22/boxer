# Final artifact verification

Date: 2026-10-07. Not Human UAT.

SOURCE_SHA = e81ab4368ec222722a3e2eb7d3ba396d1e698829
BOXER_BUILD_MARKER = the same full SHA
productVersion = r2-e81ab4368ec222722a3e2eb7d3ba396d1e698829
metadata source_sha = the same full SHA

Before invocation: tracked source clean, builds/web/boxer-round2 absent.
Entry point: BoxerP0.Editor.Round2Build.Web, Unity 6000.5.8f1.
BuildPipeline result Succeeded, 238.1300787 seconds, 58694996 bytes.
ROUND2_WEB_BUILD_SUCCESS and provenance were generated. All six generated file
hashes were independently recomputed and matched provenance.txt; HTML embeds
the final productVersion. After the build, tracked scene/project settings were
restored and git status --porcelain --untracked-files=no was empty.

The Editor process later crashed with an out-of-memory message after the build
success marker and source restoration (build-final.log lines 1924 and 2028).
This is not a clean editor exit. No attribution of the memory failure to the
fighter, another process, or a particular subsystem is established by this run.
The artifact is therefore checked separately by local browser smoke rather than
equating editor shutdown with build validity.

ZIP: ramirez-round2-e81ab436.zip, 40027928 bytes.
SHA256: 96243a8b6011920d3eb26afbe24163e9d71615d24a727c3ef458378b731dd6da
All ZIP entries were read back and generated payload hashes matched provenance.
The ZIP contains the same seven build/provenance files, under boxer-round2/.

Six frozen combat source files were compared with STARTING_SHA and had no diff:
Round2Motion, Round2CombatRig, Round2Footwork, OpponentBoxer, PlayerBoxer,
P1PunchMechanics. No historical regression threshold was changed.

The initial web smoke produced web-baseline.png and web-candidate.png at READY
but stalled during teardown before persisting a result JSON. Its test-owned Node
process was stopped; no user browser session was touched. Those partial images
are not counted as a complete smoke or active-combat performance result.
web-active-smoke.cjs is an evidence-only harness with focused canvas, existing
desktop keyboard controls, frozen onboarding timeout progression, and bounded
teardown. Its JSON and active-bout captures are the final browser evidence.
It does not modify application source, built bytes, combat semantics, or sensors.

Earlier source-66f7a41 build remains at
D:/WORK/RESEARCH/POVGame/_ramirez-unity-source-66f7a41 (diagnostic, not final UAT).
Original historical artifact remains at
D:/WORK/RESEARCH/POVGame/_ramirez-unity-baseline-bc0b2129. Its provenance source
is 962e12398b0ae0ea73981646bcbbcd14d1368027, productVersion ev-962e12398b0ae0ea73981646bcbbcd14d1368027.
The relevant Scripts/Resources/WebGLTemplates have no diff between that source
and STARTING_SHA. Do not relabel the old artifact's source as bc0b2129.

No Pages deployment, workflow dispatch, native device test or Human UAT.
